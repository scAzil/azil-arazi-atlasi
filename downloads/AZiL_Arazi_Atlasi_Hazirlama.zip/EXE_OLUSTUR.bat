@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
%PY% -m pip install --user --upgrade pyinstaller
%PY% -m PyInstaller --noconfirm --clean --onefile --windowed --name AZiL_Arazi_Atlasi_Baslatici atlas_baslat.py
if errorlevel 1 (echo EXE olusturulamadi. & pause & exit /b 1)
echo EXE: dist\AZiL_Arazi_Atlasi_Baslatici.exe
pause
