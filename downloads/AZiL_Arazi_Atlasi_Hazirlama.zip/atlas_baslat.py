"""AZiL Arazi Atlası - kullanıcıya ait barındırılmış web sürümünü açan başlangıç aracı.
Bu sürüm yerel/offline veritabanı veya tam masaüstü uygulaması değildir.
"""
import webbrowser
import tkinter as tk
from tkinter import ttk

ATLAS_URL = "https://arazi-atlasi.chic-cabin-0509.chatgpt.site/"


def main():
    root = tk.Tk()
    root.title("AZiL Arazi Atlası — Web Başlatıcı 0.1")
    root.geometry("530x290")
    root.minsize(440, 260)
    root.configure(bg="#111216")
    frame = tk.Frame(root, bg="#111216", padx=28, pady=23)
    frame.pack(fill="both", expand=True)
    tk.Label(frame, text="AZiL / SAHA & CBS", fg="#d5f778", bg="#111216", font=("Segoe UI", 10, "bold")).pack(anchor="w")
    tk.Label(frame, text="Arazi Atlası", fg="#f4f4ef", bg="#111216", font=("Segoe UI", 24, "bold")).pack(anchor="w", pady=(7, 8))
    tk.Label(frame, text="Mevcut Arazi Atlası web uygulamasını varsayılan tarayıcıda açar.\nBu, çevrimdışı Windows sürümü değildir.",
             fg="#b9bec8", bg="#111216", justify="left", font=("Segoe UI", 10)).pack(anchor="w", pady=(0, 19))
    ttk.Button(frame, text="Arazi Atlası'nı aç", command=lambda: webbrowser.open(ATLAS_URL, new=2)).pack(anchor="w")
    tk.Label(frame, text="Önemli kayıtlarınızı uygulama içinden dışa aktararak yedekleyin.",
             fg="#b9bec8", bg="#111216", font=("Segoe UI", 9)).pack(anchor="w", pady=(18, 0))
    root.mainloop()


if __name__ == "__main__":
    main()
