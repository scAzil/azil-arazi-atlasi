@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (py -3 atlas_baslat.py) else (python atlas_baslat.py)
if errorlevel 1 (echo Python 3 kurulu olmali. & pause)
