# AZiL Arazi Atlası — Windows web başlatıcı (0.1)

**Önemli:** Bu paket mevcut [AZiL Arazi Atlası](https://arazi-atlasi.chic-cabin-0509.chatgpt.site/) web uygulamasına kısayol açar. Tam işlevli/çevrimdışı masaüstü sürümü DEĞİLDİR. Orijinal uygulamanın kaynak kodu burada mevcut olmadığından web sürümünün harita/veri özellikleri yeniden oluşturulmuş gibi gösterilmez.

- `AZiL_Arazi_Atlasi_Baslatici.zip`: Python 3 bulunan Windows'ta `BASLAT.bat` ile açılan küçük çevrimiçi başlatıcı.
- `AZiL_Arazi_Atlasi_Hazirlama.zip`: Kaynak + `EXE_OLUSTUR.bat`; Windows üzerinde PyInstaller ile başlatıcı EXE üretir.
- Gerçek bir Windows çevrimdışı sürümü hazırlamak için uygulamanın kaynakları, harita altyapısı ve veri saklama yaklaşımı ayrıca aktarılmalıdır.

**Uyarı:** Tarayıcı verilerini temizlemek yerel kayıtları etkileyebilir. Önemli verileri uygulamanın dışa aktarma seçeneklerinden yedekleyin.
