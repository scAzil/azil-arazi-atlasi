@echo off
cd /d "%~dp0"
call npm.cmd install
if errorlevel 1 goto fail
call npm.cmd start
if errorlevel 1 goto fail
exit /b 0
:fail
echo Islem tamamlanamadi. Yukaridaki hata mesajini paylasin.
pause
exit /b 1
