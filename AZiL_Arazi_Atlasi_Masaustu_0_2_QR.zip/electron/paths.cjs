const path=require('node:path');
function resolveAsset(root,address){try{const u=new URL(address);if(u.protocol!=='atlas:'||u.hostname!=='app')return null;const rel=decodeURIComponent(u.pathname).replace(/^\/+/, '');if(rel.includes('\\')||rel.includes('\0'))return null;const target=path.resolve(root,rel||'index.html');if(!target.startsWith(path.resolve(root)+path.sep))return null;return target}catch{return null}}
module.exports={resolveAsset};
