const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('atlasDesktop',Object.freeze({backup:raw=>ipcRenderer.invoke('atlas:backup',raw),openData:()=>ipcRenderer.invoke('atlas:open-data')}));
