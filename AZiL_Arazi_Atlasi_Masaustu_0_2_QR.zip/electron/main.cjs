'use strict';
const {app,BrowserWindow,protocol,ipcMain,shell,Menu,dialog}=require('electron');
const fs=require('node:fs/promises');
const path=require('node:path');
const {resolveAsset}=require('./paths.cjs');
protocol.registerSchemesAsPrivileged([{scheme:'atlas',privileges:{standard:true,secure:true,supportFetchAPI:true,corsEnabled:true}}]);
app.setPath('userData',path.join(app.getPath('appData'),'AZiL-Arazi-Atlasi'));
let win,backupQueue=Promise.resolve();
if(!app.requestSingleInstanceLock()){app.quit()}else{
app.on('second-instance',()=>{if(win){if(win.isMinimized())win.restore();win.focus()}});
app.whenReady().then(async()=>{
 const root=path.join(__dirname,'../app');
 protocol.handle('atlas',async request=>{try{const file=resolveAsset(root,request.url);if(!file)return new Response('Not found',{status:404});const bytes=await fs.readFile(file);const ext=path.extname(file);const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.geojson':'application/geo+json','.svg':'image/svg+xml','.png':'image/png','.webmanifest':'application/manifest+json'};return new Response(bytes,{headers:{'Content-Type':types[ext]||'application/octet-stream'}})}catch{return new Response('Not found',{status:404})}});
 const trusted=e=>e.sender===win?.webContents&&e.senderFrame?.url.startsWith('atlas://app/');
 ipcMain.handle('atlas:open-data',e=>{if(!trusted(e))throw Error('İzin yok');return shell.openPath(app.getPath('userData'))});
 ipcMain.handle('atlas:backup',(e,raw)=>{if(!trusted(e)||typeof raw!=='string'||Buffer.byteLength(raw)>300*1024*1024)throw Error('Yedek boyutu veya kaynak geçersiz');const snapshot=JSON.parse(raw);if(!Array.isArray(snapshot.records?.records)||!Array.isArray(snapshot.layers?.layers))throw Error('Geçersiz yedek');
 const work=backupQueue.then(async()=>{const base=path.join(app.getPath('userData'),'Yedekler');await fs.mkdir(base,{recursive:true});const temp=path.join(base,'.tmp-'+Date.now());await fs.mkdir(temp);try{await fs.writeFile(path.join(temp,'Saha-Kayitlari.json'),JSON.stringify(snapshot.records));await fs.writeFile(path.join(temp,'Atlas-Katmanlari.json'),JSON.stringify(snapshot.layers));await fs.rename(temp,path.join(base,new Date().toISOString().replace(/[:.]/g,'-')))}catch(error){await fs.rm(temp,{recursive:true,force:true});throw error}return true});backupQueue=work.catch(()=>{});return work});
 win=new BrowserWindow({width:1380,height:900,minWidth:850,minHeight:600,title:'AZiL Arazi Atlası',webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true,webSecurity:true}});
 win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
 win.webContents.on('will-navigate',(event,url)=>{if(!url.startsWith('atlas://app/'))event.preventDefault()});
 win.webContents.session.setPermissionRequestHandler((_wc,_permission,callback)=>callback(false));
 Menu.setApplicationMenu(Menu.buildFromTemplate([{label:'Dosya',submenu:[{label:'Arşiv klasörünü aç',click:()=>shell.openPath(app.getPath('userData'))},{type:'separator'},{role:'quit',label:'Çıkış'}]},{label:'Düzenle',submenu:[{role:'undo'},{role:'redo'},{type:'separator'},{role:'cut'},{role:'copy'},{role:'paste'},{role:'selectAll'}]},{label:'Görünüm',submenu:[{role:'resetZoom'},{role:'zoomIn'},{role:'zoomOut'},{role:'togglefullscreen'},{role:'toggleDevTools',label:'Hata inceleme'}]}]));
 win.loadURL('atlas://app/index.html');
}).catch(e=>{dialog.showErrorBox('Arazi Atlası açılamadı',e.message);app.quit()});
app.on('window-all-closed',()=>app.quit());
}
